<?php
/**
 * @author  Syntlex Dev https://syntlex.info
 * @copyright 2005-2021  Syntlex Dev
 * @license : GNU General Public License
 * @subpackage Payment plugin for Roskassa
 * @Product : Payment plugin for Roskassa
 * @Date  : 24 March 2021
 * @Contact : cmsmodulsdever@gmail.com
 * This plugin is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation;
 *  either version 2 (GPLv2) of the License, or (at your option) any later version.
 *
 * This plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
 *
 **/

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Roskassa extends PaymentModule
{
    private $_html = '';

    public function __construct()
    {
        $this->name = 'roskassa';
        $this->author = 'Roskassa';
        $this->tab = 'payments_gateways';
        $this->version = '1.1.3';
        $this->need_instance = 1;
        $this->bootstrap = true;

        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);
        $this->module_key = '37928de7857aec8ad8a009534abfa24c';
        $this->controllers = array('status', 'success', 'fail', 'payment');
        $this->is_eu_compatible = 1;
        $this->currencies = true;

        parent::__construct();

        $this->displayName = $this->l('Roskassa');
        $this->description = $this->l('Payment via Roskassa');

        $updateConfig = array('PS_OS_CHEQUE', 'PS_OS_PAYMENT', 'PS_OS_PREPARATION',
        'PS_OS_SHIPPING', 'PS_OS_CANCELED', 'PS_OS_REFUND',
        'PS_OS_ERROR', 'PS_OS_OUTOFSTOCK', 'PS_OS_BANKWIRE',
        'PS_OS_PAYPAL', 'PS_OS_WS_PAYMENT');
        if (!Configuration::get('PS_OS_PAYMENT')) {
            foreach ($updateConfig as $u) {
                if (!Configuration::get($u) && defined('_'.$u.'_')) {
                    Configuration::updateValue($u, constant('_'.$u.'_'));
                }
            }
        }
    }

    public function install()
    {
        if (!parent::install() || !$this->registerHook('paymentReturn') || !$this->registerHook('paymentOptions')) {
            return false;
        }
        return true;
    }

    public function uninstall()
    {
        return parent::uninstall() && Configuration::deleteByName('roskassa');
    }

    public function getContent()
    {
        if (Tools::isSubmit('submitroskassa')) {
            $this->postProcess();
        }

        $this->_html .= $this->renderForm();

        return $this->_html;
    }

    private function postProcess()
    {
        Configuration::updateValue('merchant_url', Tools::getValue('merchant_url'));
        Configuration::updateValue('merchant_id', Tools::getValue('merchant_id'));
        Configuration::updateValue('secret_key', Tools::getValue('secret_key'));
        Configuration::updateValue('roskassa_log', Tools::getValue('roskassa_log'));
        Configuration::updateValue('test_mode', Tools::getValue('test_mode'));

        $this->_html .= $this->displayConfirmation($this->l('Settings updated.'));
    }

    public function renderForm()
    {
        $options = array(
          array(
            'id_option' => 0,
            'name' => 'No'
        ),
          array(
            'id_option' => 1,
            'name' => 'Yes'
        ),
        );
        $this->fields_form[0]['form'] = array(
            'legend' => array(
                'title' => $this->l('Настройка'),
                'image' => _PS_ADMIN_IMG_.'information.png'
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Merchant URL'),
                    'desc' => $this->l('Link for payment'),
                    'name' => 'merchant_url'
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Store ID'),
                    'desc' => $this->l('The identifier of the store registered with Roskassa'),
                    'name' => 'merchant_id'
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Secret key'),
                    'desc' => $this->l('Secret key'),
                    'name' => 'secret_key'
                ),
                array(
                    'type' => 'select',
                    'label' => $this->l('Test mode'),
                    'desc' => $this->l('Test mode'),
                    'name' => 'test_mode',
                    'options' => array(
                        'query' => $options,
                        'id' => 'id_option',
                        'name' => 'name'
                    )
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Log file path'),
                    'desc' => $this->l('Path to the log file of payments via Roskassa (for example, /roskassa_orders.log)'),
                    'name' => 'roskassa_log'
                )
            ),
            'submit' => array(
                'name' => 'submitroskassa',
                'title' => $this->l('Save')
            )
        );
        $this->fields_form[1]['form'] = array(
            'legend' => array(
                'title' => $this->l('Vendor Configuration Information') ,
                'image' => _PS_ADMIN_IMG_.'information.png'
            ),
            'input' => array(
                array(
                    'type' => 'text',
                    'label' => $this->l('Success URL'),
                    'desc' => $this->l('The URL that will be used for the request in case of successful payment.'),
                    'name' => 'success_url',
                    'size' => 120
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Fail URL'),
                    'desc' => $this->l('The URL to be used for the request in case of a failed payment.'),
                    'name' => 'fail_url',
                    'size' => 120
                ),
                array(
                    'type' => 'text',
                    'label' => $this->l('Status URL'),
                    'desc' => $this->l('Used for payment notification.'),
                    'name' => 'status_url',
                    'size' => 120
                )
            )
        );

        $helper = new HelperForm();
        $helper->module = $this;
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $helper->submit_action = 'submitroskassa';
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.
        '&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        return $helper->generateForm($this->fields_form);
    }

    public function getConfigFieldsValues()
    {
        $fields_values = array();

        $fields_values['merchant_url'] = Configuration::get('merchant_url') == '' ? '//pay.roskassa.net' : Configuration::get('merchant_url');
        $fields_values['merchant_id'] = Configuration::get('merchant_id');
        $fields_values['secret_key'] = Configuration::get('secret_key');
        $fields_values['roskassa_log'] = Configuration::get('roskassa_log');
        $fields_values['test_mode'] = Configuration::get('test_mode');

        $fields_values['status_url'] = $this->context->link->getModuleLink('roskassa', 'status', array(), true);
        $fields_values['success_url'] = $this->context->link->getModuleLink('roskassa', 'success', array(), true);
        $fields_values['fail_url'] = $this->context->link->getModuleLink('roskassa', 'fail', array(), true);

        return $fields_values;
    }

    public function hasProductDownload($cart)
    {
        $products = $cart->getProducts();

        if (!empty($products)) {
            foreach ($products as $product) {
                $pd = ProductDownload::getIdFromIdProduct((int)($product['id_product']));
                if ($pd and Validate::isUnsignedInt($pd)) {
                    return true;
                }
            }
        }

        return false;
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }

        if ($this->hasProductDownload($params['cart'])) {
            return;
        }

        $newOption = new PaymentOption();
        $newOption
        ->setCallToActionText($this->trans('Roskassa', array(), 'Modules.Roskassa.Shop'))
        ->setAction($this->context->link->getModuleLink($this->name, 'payment', array(), true))
        ->setAdditionalInformation($this->context->smarty->fetch('module:roskassa/views/templates/hook/roskassa_intro.tpl'));

        $payment_options = [
            $newOption,
        ];
        return $payment_options;
    }
}
