<?php
/**
 * @author  Syntlex Dev https://syntlex.info
 * @copyright 2005-2021  Syntlex Dev
 * @license : GNU General Public License
 * @subpackage Payment plugin for Roskassa
 * @Product : Payment plugin for Roskassa
 * @Date  : 24 March 2021
 * @Contact : cmsmodulsdever@gmail.com
 * This plugin is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2 (GPLv2) of the License, or (at your option) any later version.
 *
 * This plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
 *
 **/

global $_MODULE;
$_MODULE = array();
$_MODULE['<{roskassa}prestashop>roskassa_1801d964562765a451fa0d33279d172f'] = 'Payment via Roskassa';
$_MODULE['<{roskassa}prestashop>roskassa_f38f5974cdc23279ffe6d203641a8bdf'] = 'Settings updated.';
$_MODULE['<{roskassa}prestashop>roskassa_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{roskassa}prestashop>roskassa_4825a5f07b97f1157ebb9a0b91c73417'] = 'Merchant URL';
$_MODULE['<{roskassa}prestashop>roskassa_7f29d04821e39f71bb816705353fc163'] = 'URL for the payment';
$_MODULE['<{roskassa}prestashop>roskassa_1bcfdc4388309d3cd580dc58c3c39034'] = 'ID store';
$_MODULE['<{roskassa}prestashop>roskassa_ace7f2c128698c1354c81ab027942364'] = 'Path to the log file';
$_MODULE['<{roskassa}prestashop>roskassa_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{roskassa}prestashop>roskassa_86d38d2a0eba3ac1373011c27bf27425'] = 'Merchant configuration information';
$_MODULE['<{roskassa}prestashop>roskassa_4a248da3df07d8b80a572649af38cec9'] = 'Success URL';
$_MODULE['<{roskassa}prestashop>roskassa_9247a9dbab3f55add5d95422f165d6c7'] = 'URL to be used for query in case of successful payment.';
$_MODULE['<{roskassa}prestashop>roskassa_eff5520404cfa1852109ba28ac48b5ea'] = 'Fail URL';
$_MODULE['<{roskassa}prestashop>roskassa_8e5bf36dfb163d9347874dd2e018f586'] = 'URL to be used for query in case of failed payment.';
$_MODULE['<{roskassa}prestashop>roskassa_c182e5e660af38e5c5b16fc10bf91565'] = 'Status URL';
$_MODULE['<{roskassa}prestashop>roskassa_55077fdc1e173cf7db5071e294bdcf19'] = 'Used for payment notification.';
