<?php
/**
 * @author  Syntlex Dev https://syntlex.info
 * @copyright 2005-2021  Syntlex Dev
 * @license : GNU General Public License
 * @subpackage Payment plugin for Roskassa
 * @Product : Payment plugin for Roskassa
 * @Date  : 24 March 2021
 * @Contact : cmsmodulsdever@gmail.com
 * This plugin is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation; either version 2 (GPLv2) of the License, or (at your option) any later version.
 *
 * This plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
 *
 **/

global $_MODULE;
$_MODULE = array();
$_MODULE['<{roskassa}prestashop>roskassa_8f6c803f523fc6ed2e9f12eafb28a1ad'] = 'Оплата через Roskassa';
$_MODULE['<{roskassa}prestashop>roskassa_f38f5974cdc23279ffe6d203641a8bdf'] = 'Настройки обновлены';
$_MODULE['<{roskassa}prestashop>roskassa_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{roskassa}prestashop>roskassa_4825a5f07b97f1157ebb9a0b91c73417'] = 'URL мерчанта';
$_MODULE['<{roskassa}prestashop>roskassa_7f29d04821e39f71bb816705353fc163'] = 'URL- адрес для оплаты';
$_MODULE['<{roskassa}prestashop>roskassa_1bcfdc4388309d3cd580dc58c3c39034'] = 'Идентификатор магазина';
$_MODULE['<{roskassa}prestashop>roskassa_8b39464a1bed791f08f5586732648d4e'] = 'Идентификатор магазина, зарегистрированного в системе Roskassa';
$_MODULE['<{roskassa}prestashop>roskassa_be6a18e86195f4e655dabcfba532598e'] = 'Секретный ключ';
$_MODULE['<{roskassa}prestashop>roskassa_ace7f2c128698c1354c81ab027942364'] = 'Путь к файлу журнала';
$_MODULE['<{roskassa}prestashop>roskassa_4f4917bf4042070631111544b4cc74b4'] = 'Путь к файлу журнала для платежей через Roskassa (например, /roskassa_orders.log)';
$_MODULE['<{roskassa}prestashop>roskassa_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{roskassa}prestashop>roskassa_86d38d2a0eba3ac1373011c27bf27425'] = 'Информация для настройки магазина';
$_MODULE['<{roskassa}prestashop>roskassa_4a248da3df07d8b80a572649af38cec9'] = 'URL успешной оплаты';
$_MODULE['<{roskassa}prestashop>roskassa_9247a9dbab3f55add5d95422f165d6c7'] = 'URL-адрес, используемый для запроса в случае успешной оплаты.';
$_MODULE['<{roskassa}prestashop>roskassa_eff5520404cfa1852109ba28ac48b5ea'] = 'URL неуспешной оплаты';
$_MODULE['<{roskassa}prestashop>roskassa_8e5bf36dfb163d9347874dd2e018f586'] = 'URL-адрес, используемый для запроса в случае неудачного платежа';
$_MODULE['<{roskassa}prestashop>roskassa_c182e5e660af38e5c5b16fc10bf91565'] = 'URL обработчика';
$_MODULE['<{roskassa}prestashop>roskassa_55077fdc1e173cf7db5071e294bdcf19'] = 'Используется для уведомления об оплате.';
$_MODULE['<{roskassa}prestashop>status_7fed70b9158e58d4313fd517be45e073'] = ' - не совпадают цифровые подписи';
$_MODULE['<{roskassa}prestashop>status_5c2debf906f1c267b9311e62bf0ecba4'] = 'Ошибка оплаты';
