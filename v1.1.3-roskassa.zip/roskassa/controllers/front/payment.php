<?php
/**
 * @author  Syntlex Dev https://syntlex.info
 * @copyright 2005-2021  Syntlex Dev
 * @license : GNU General Public License
 * @subpackage Payment plugin for Roskassa
 * @Product : Payment plugin for Roskassa
 * @Date  : 24 March 2021
 * @Contact : cmsmodulsdever@gmail.com
 * This plugin is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation;
 *  either version 2 (GPLv2) of the License, or (at your option) any later version.
 *
 * This plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
 *
 **/

class RoskassaPaymentModuleFrontController extends ModuleFrontController
{
    protected $templateName = 'module:roskassa/views/templates/front/roskassa_form.tpl';
    public $ssl = true;

    public function initContent()
    {
        parent::initContent();

        $cart = $this->context->cart;
        $customer = new Customer((int)$cart->id_customer);

        if ($ordernumber = Order::getOrderByCartId($cart->id)) {
            $order = new Order((int)$ordernumber);
            if ($order->hasBeenPaid()) {
                Tools::redirectLink(__PS_BASE_URI__ . 'order-confirmation.php?key=' . $order->secure_key .
                    '&id_cart=' . $order->id_cart .
                    '&id_module=' . $this->module->id . '&id_order=' . $order->id);
                return;
            }
        }

        $products = $cart->getProducts();

        $data = false;

        $i = 0;
        foreach ($products as $value) {
            $data['["receipt"]["items"]["'.$i.'"]["name"]'] = $value['name'];
            $data['["receipt"]["items"]["'.$i.'"]["count"]'] = $value['cart_quantity'];
            $data['["receipt"]["items"]["'.$i.'"]["price"]'] = $value['price'];
            $i++;
        }

        $total_shipping_wt = $cart->getTotalShippingCost();

        if (!empty($total_shipping_wt)) {
            $data['["receipt"]["items"]["'.$i.'"]["name"]'] = "Доставка";
            $data['["receipt"]["items"]["'.$i.'"]["count"]'] = 1;
            $data['["receipt"]["items"]["'.$i.'"]["price"]'] = $total_shipping_wt;
        }

        $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
        $currency = new Currency((int)($cart->id_currency));
        $amount = number_format($cart->getOrderTotal(true, Cart::BOTH), 2, '.', '');

        $arrSign = array(
            'shop_id' => Configuration::get('merchant_id'),
            'order_id' => (int)$cart->id,
            'amount' => $amount,
            'currency' => $currency->iso_code,
            'test' => Configuration::get('test_mode')
        );

        ksort($arrSign);
        $str = http_build_query($arrSign);
        $mnt_signature = md5($str . Configuration::get('secret_key'));

        $this->context->smarty->assign(array(
            'm_url' => Configuration::get('merchant_url'),
            'shop_id' => Configuration::get('merchant_id'),
            'order_id' => (int)$cart->id,
            'test' => Configuration::get('test_mode'),
            'currency' => $currency->iso_code,
            'amount' => $amount,
            'sign' => $mnt_signature,
            'products' => $data,
            'success_url' => Tools::getShopDomain(true, true) . __PS_BASE_URI__ .
            'index.php?controller=order-confirmation&id_cart=' . ($cart->id) .
            '&id_module=' . ($this->module->id) . '&key=' . $customer->secure_key .
            '&order_id=' . $cart->id . '&status=success',
            'fail_url' => Tools::getShopDomain(true, true) . __PS_BASE_URI__ .
            'index.php?controller=order-confirmation&id_cart=' . ($cart->id) .
            '&id_module=' . ($this->module->id) . '&key=' . $customer->secure_key .
            '&order_id=' . $cart->id . '&status=fail'
        ));

        $m_orderid = (int)$cart->id;
        $total = $cart->getOrderTotal(true, Cart::BOTH);

        $this->module->validateOrder($m_orderid, Configuration::get('PS_OS_CHEQUE'), $total, $this->module->displayName, null, array(), (int)$currency->id, false, $customer->secure_key);

        $this->setTemplate($this->templateName);
    }

    private function getLang()
    {
        $cart = $this->context->cart;
        $language = new Language((int)$cart->id_lang);
        $languageCode = $language->iso_code;

        if ($languageCode == 'ru') {
            return 'ru';
        } else {
            return 'en';
        }
    }
}
