<?php
/**
 * @author  Syntlex Dev https://syntlex.info
 * @copyright 2005-2021  Syntlex Dev
 * @license : GNU General Public License
 * @subpackage Payment plugin for Roskassa
 * @Product : Payment plugin for Roskassa
 * @Date  : 24 March 2021
 * @Contact : cmsmodulsdever@gmail.com
 * This plugin is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation;
 *  either version 2 (GPLv2) of the License, or (at your option) any later version.
 *
 * This plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
 *
 **/

class RoskassaStatusModuleFrontController extends ModuleFrontController
{
    public $display_header = false;
    public $display_column_left = false;
    public $display_column_right = false;
    public $display_footer = false;
    public $ssl = true;
    
    public function postProcess()
    {
        parent::postProcess();
        
        if (Tools::getValue('id') && Tools::getValue('sign')) {
            $m_orderid = Tools::getValue('order_id');
            $roskassa = $this->module;
            $err = false;
            $message = '';
            
            // запись логов

            $log_text =
            "--------------------------------------------------------\n" .
            "shop               " . Tools::getValue('shop_id') . "\n" .
            "amount             " . Tools::getValue('amount') . "\n" .
            "operation id       " . Tools::getValue('id') . "\n" .
            "order id           " . Tools::getValue('order_id') . "\n" .
            "e-mail client      " . Tools::getValue('email') . "\n" .
            "currency           " . Tools::getValue('currency') . "\n" .
            "sign               " . Tools::getValue('sign') . "\n\n";
            
            $log_file = Configuration::get('roskassa_log');
            
            if (!empty($log_file)) {
                file_put_contents($_SERVER['DOCUMENT_ROOT'] . $log_file, $log_text, FILE_APPEND);
            }

            // проверка цифровой подписи и ip

            $post = $_POST;
            unset($post['sign']);
            ksort($post);
            $str = http_build_query($post);
            $sign_hash = md5($str . Configuration::get('secret_key'));

            if (Tools::getValue('sign') != $sign_hash) {
                $message .= $roskassa->l(' - do not match the digital signature', 'status') . "\n";
                $err = true;
            }

            // проверка статуса

            $order = new Order((int)$m_orderid);

            if (!$err) {
                $history = new OrderHistory();
                $history->id_order = (int)$m_orderid;

                if (Tools::getValue('sign') == $sign_hash) {
                    if ($order->current_state !== Configuration::get('PS_OS_WS_PAYMENT')) {
                        $history->changeIdOrderState((int) Configuration::get('PS_OS_WS_PAYMENT'), (int) ($m_orderid));
                        exit('YES');
                    }
                } else {
                    $message .= $roskassa->l(' - do not match the digital signature', 'status') . "\n";
                    $err = true;
                }
            }
            if ($err) {
                if ($order->current_state != Configuration::get('PS_OS_ERROR')) {
                    //$orderStatusId = Configuration::get('PS_OS_ERROR');
                    $history->changeIdOrderState((int) Configuration::get('PS_OS_ERROR'), (int) ($m_orderid));
                    //$order->setCurrentState($orderStatusId);
                }
            }

            exit($m_orderid . ' | error | ' . $message);
        }
    }
}
