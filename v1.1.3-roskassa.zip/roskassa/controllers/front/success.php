<?php
/**
 * @author  Syntlex Dev https://syntlex.info
 * @copyright 2005-2021  Syntlex Dev
 * @license : GNU General Public License
 * @subpackage Payment plugin for Roskassa
 * @Product : Payment plugin for Roskassa
 * @Date  : 24 March 2021
 * @Contact : cmsmodulsdever@gmail.com
 * This plugin is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License
 *  as published by the Free Software Foundation;
 *  either version 2 (GPLv2) of the License, or (at your option) any later version.
 *
 * This plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
 *
 **/

class RoskassaSuccessModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    
    public function initContent()
    {
        parent::initContent();
        
        $m_orderid = Tools::getValue('order_id');
        $order = new Order((int)$m_orderid);
        $customer = new Customer((int)$order->id_customer);

        Tools::redirectLink(__PS_BASE_URI__ . 'order-confirmation.php?key=' . $customer->secure_key . '&id_cart=' . $order->id_cart .
            '&id_module=' . $this->module->id . '&id_order=' . $order->id);
    }
}
