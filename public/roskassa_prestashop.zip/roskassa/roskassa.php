<?php
/**
 * @author  Syntlex Dev https://syntlex.info
 * @copyright 2005-2021  Syntlex Dev
 * @license : GNU General Public License
 * @subpackage Payment plugin for Roskassa
 * @Product : Payment plugin for Roskassa
 * @Date  : 24 March 2021
 * @Contact : cmsmodulsdever@gmail.com
 * This plugin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 *  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * See the GNU General Public License for more details <http://www.gnu.org/licenses/>.
 *
 **/

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

if (!defined('_PS_VERSION_'))
	exit;

class RosKassa extends PaymentModule
{
	protected $_html = '';
	protected $_postErrors = array();

	public function __construct()
	{
		$this->name = 'roskassa';
		$this->tab = 'payments_gateways';
		$this->version = '1.1.2';
		$this->author = 'RosKassa';
		$this->controllers = array('validation');
		$this->bootstrap = true;
		$this->currencies = true;
		$this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);
	    $this->module_key = '37928de7857aec8ad8a009534abfa24c';

		


		parent::__construct();

		$this->displayName = 'RosKassa';
		$this->description = 'Приём оплаты через RosKassa';

		if (!count(Currency::checkPaymentCurrencies($this->id))) {
			$this->warning = 'No currency has been set for RosKassa.';
		}
	}

 /**
	* create new order statuses
	*
	* @param $status
  * @param $title
	* @param $color
	* @param $template
	* @param $invoice
	* @param $send_email
	* @param $paid
	* @param $logable
	*/
	public function createRosKassaPaymentStatus($status, $title, $color, $template, $invoice, $send_email, $paid, $logable)
	{
		$ow_status = Configuration::get($status);
		if ($ow_status === false)
		{
			$order_state = new OrderState();
	        //$order_state->id_order_state = (int)$key;
		}
		else
			$order_state = new OrderState((int)$ow_status);

		$order_state->module_name = $this->name;
		$langs = Language::getLanguages();

		foreach ($langs as $lang)
			$order_state->name[$lang['id_lang']] = utf8_encode(html_entity_decode($title));

		$order_state->invoice = $invoice;
		$order_state->send_email = $send_email;

		if ($template != '')
			$order_state->template = $template;

		if ($paid != '')
			$order_state->paid = $paid;

		$order_state->logable = $logable;
		$order_state->color = $color;
		$order_state->save();

		Configuration::updateValue($status, (int)$order_state->id);

		copy(dirname(__FILE__).'/views/img/roskassa.svg', dirname(__FILE__).'/../../img/os/'.(int)$order_state->id.'.svg');
	}

	public function install()
	{
		if (!parent::install() || !$this->registerHook('paymentOptions'))
			return false;

		Configuration::updateValue('ROSKASSA_PAYMENT_URL', 'pay.roskassa.net');
		Configuration::updateValue('ROSKASSA_MNT_ID', '');
		Configuration::updateValue('ROSKASSA_MNT_DATAINTEGRITY_CODE', '');
		Configuration::updateValue('ROSKASSA_MNT_TEST_MODE', '0');

		$this->createRosKassaPaymentStatus('ROSKASSA_OS_WAITING', 'Awaiting RosKassa payment', '#3333FF', 'payment_waiting', false, false, '', false);
		$this->createRosKassaPaymentStatus('ROSKASSA_OS_SUCCEED', 'Accepted RosKassa payment', '#32cd32', 'payment', true, true, true, true);

		return true;
	}

	public function hookPaymentOptions($params)
	{
		if (!$this->active)
			return null;
		if (!$this->checkCurrency($params['cart']))
			return null;

		$embeddedOption = new PaymentOption();
		$embeddedOption
		->setCallToActionText('Платежная система RosKassa')
		->setAdditionalInformation($this->context->smarty->fetch('module:roskassa/views/templates/front/payment_infos.tpl'))
		->setAction($this->context->link->getModuleLink($this->name, 'validation', array(), true))
		->setLogo(Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/views/img/roskassa.svg'));

		return array($embeddedOption);
	}

	public function checkCurrency($cart)
	{
		$currency_order = new Currency($cart->id_currency);
		$currencies_module = $this->getCurrency($cart->id_currency);

		if (is_array($currencies_module)) {
			foreach ($currencies_module as $currency_module) {
				if ($currency_order->id == $currency_module['id_currency']) {
					return true;
				}
			}
		}
		return false;
	}

	public function uninstall()
	{
		Configuration::deleteByName('ROSKASSA_PAYMENT_URL');
		Configuration::deleteByName('ROSKASSA_MNT_ID');
		Configuration::deleteByName('ROSKASSA_MNT_DATAINTEGRITY_CODE');
		Configuration::updateValue('ROSKASSA_MNT_TEST_MODE');

		return parent::uninstall();
	}

	public function getContent()
	{
		if (Tools::isSubmit('submitModule'))
		{
			Configuration::updateValue('ROSKASSA_PAYMENT_URL', Tools::getvalue('roskassa_payment_url'));
			Configuration::updateValue('ROSKASSA_MNT_ID', Tools::getvalue('roskassa_mnt_id'));
			Configuration::updateValue('ROSKASSA_MNT_DATAINTEGRITY_CODE', Tools::getvalue('roskassa_mnt_dataintegrity_code'));

			$this->_html .= $this->displayConfirmation($this->l('Configuration updated'));
		}
		$this->context->smarty->assign(
	      array(
	      		'html' => $this->_html,
	      		'display_name' => $this->displayName,
	      		'l' => $this->l('Подробную информацию можете получить на сайте.'),
	          'action' => Tools::htmlentitiesutf8($_SERVER['REQUEST_URI']),
	          'setting' => $this->l('Settings'),
	          'payment_url' => $this->l('Payment URL'),
	          'account_number' => $this->l('Account number'),
	          'roskassa_mnt_id' => Configuration::get('ROSKASSA_MNT_ID'),
	          'data_integrity_code' => $this->l('Data integrity code'),
	          'roskassa_mnt_dataintegrity_code' => Configuration::get('ROSKASSA_MNT_DATAINTEGRITY_CODE'),
	          'mode' => $this->l('Mode'),
	          'roskassa_mnt_test_mode' => (!Tools::getValue('roskassa_mnt_test_mode', Configuration::get('ROSKASSA_MNT_TEST_MODE')) ? 'checked="checked"' : ''),
	          'roskassa_mnt_test_mode1' => (Tools::getValue('roskassa_mnt_test_mode', Configuration::get('ROSKASSA_MNT_TEST_MODE')) ? 'checked="checked"' : ''),
	          'production' => $this->l('Production'),
	          'test' => $this->l('Test'),
	          'update_settings' => $this->l('Update settings')
			      )
			  );
		return $this->display(__FILE__, 'views/templates/front/roskassa.tpl');
	}
}
?>
